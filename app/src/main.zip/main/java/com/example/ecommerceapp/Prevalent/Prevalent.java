package com.example.codingcafe.ecommerce.Prevalent;

import com.example.codingcafe.ecommerce.Model.Users;

public class Prevalent
{
    public static Users currentOnlineUser;

    public static final String UserPhoneKey = "UserPhone";
    public static final String UserPasswordKey = "UserPassword";
}
